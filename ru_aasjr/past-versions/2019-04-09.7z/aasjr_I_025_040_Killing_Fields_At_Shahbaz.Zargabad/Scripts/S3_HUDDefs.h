//Respawn Dlg
#define RespawnDIDD	10050
#define ADMINDialogIDD 10051


#define RespawnDIDC	10500
#define RespawnDMAPIDC	10501
#define RespawnDGIDC	10502 //gradient
#define RespawnDBtnIDC	10503
#define RespawnDClassIDC	10504
#define RespawnDClassLBIDC	10505
#define RespawnDApplyIDC	10506
#define RespawnDPreviewIDC	10507

