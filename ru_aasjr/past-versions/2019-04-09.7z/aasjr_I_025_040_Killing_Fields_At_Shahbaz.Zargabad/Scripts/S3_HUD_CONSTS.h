#define S3_UI_X 0.5
#define S3_UI_Y 0.55
#define S3_UI_R_W 0.5
#define S3_UI_R_H 0.38
#define S3_UI_BH 0.06
#define GUI_BTX		(safeZoneH+ safeZoneY)