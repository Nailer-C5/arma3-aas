#define S3_MISSION_VD 800
#define S3_NAME Chaman Battle

#define S3_WEST_AI  ["rhsusf_usmc_marpat_wd_rifleman","rhsusf_usmc_marpat_wd_rifleman_m590","rhsusf_usmc_marpat_wd_rifleman_law","rhsusf_usmc_marpat_wd_rifleman","rhsusf_usmc_marpat_wd_rifleman","rhsusf_usmc_marpat_wd_rifleman_m4","rhsusf_usmc_marpat_wd_rifleman_m4","rhsusf_usmc_marpat_wd_rifleman","rhsusf_usmc_marpat_wd_rifleman"]
#define S3_EAST_AI ["rhs_msv_emr_rifleman","rhs_msv_emr_efreitor","rhs_msv_emr_junior_sergeant","rhs_msv_emr_machinegunner","rhs_msv_emr_officer","rhs_msv_emr_arifleman","rhs_msv_emr_marksman","rhs_msv_emr_sergeant","rhs_msv_emr_RShG2","rhs_msv_emr_grenadier"]

#define S3_VehSpawn 60
#define S3_TankSpawn 300
#define S3_HeliSpawn 300
#define S3_PlaneSpawn 300
#define S3_BastardSpawn 600

#define S3_MISSION_Rules 1